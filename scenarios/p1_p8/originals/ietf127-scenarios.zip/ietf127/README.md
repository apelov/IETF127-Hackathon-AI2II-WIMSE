# IETF 127 Hackathon: agent call-chain scenarios (WIMSE, AI2II project)

Scenario files for Alexander Pelov's WIMSE interop run (Saturday 14 November 2026, San Francisco, remote
participation). One JSON file per scenario, all in format `ietf127-wimse-scenario/1`.

| File | Scenario | Proposed by | Basis |
|---|---|---|---|
| P1 | Status list unreachable: confirmed revocation, expired cache, unavailable service, low-value grace, one element in a chain | Ben Le | -00, -01 |
| P2 | Revocation after delegation, before effect; time to first refusal against the bound | Ben Le, Iman Schrock, Alexander Pelov | -00, test policy |
| P3 | Delegation that widens (host, methods, lifetime, tools, unknown member) | Ben Le | -00, -01 |
| P4 | Cumulative limit across two services | Ben Le | -01 |
| P5 | Request rewritten in transit | Ben Le | -00, -01 |
| P6 | Tool description or build changes between hops | Ben Le | -00 |
| P7 | Approval display differs from the executed action | Arun Thallapelly | external (OASNT) |
| P8 | Final hop to a bearer-only third-party API | Kieran Sweeney | external (credential-delegation) |

Each case carries its expected decision, the reason to log and whether any effect occurred. `basis` says
where the expectation comes from: `-00` is the published draft-le-agent-passport-00, `-01` is a planned change
(posted after IETF 127), `test-policy` is a local-policy choice fixed so results compare, and `external` is
another draft's rule.

The three status refusals (`status-revoked`, `status-stale`, `status-unavailable`) are logged separately even
when the test policy denies all three, so a run shows whether the revocation check itself worked.

Regenerate the files with `python3 docs/hackathon/ietf127/gen_scenarios.py`.
